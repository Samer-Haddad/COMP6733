/**
 * \file
 *         A very simple Contiki application showing how Contiki programs look
 * \author
 *         mds
 */

#include "contiki.h"
#include <stdio.h> /* For printf() */
#include "dev/leds.h"
#include "dev/serial-line.h"
#include "string.h"
#include "buzzer.h"
#include "dev/cc26xx-uart.h"
#include "ieee-addr.h"
#include "sys/timer.h"
#include "sys/stimer.h"
#include "sys/etimer.h"
#include "sys/ctimer.h"


#define LEDS_OFF 0
int led_state = LEDS_OFF;
static struct ctimer led_timer;
static struct ctimer led_off_timer;

int buz_state = 0;
int buz_freq = 1000;
static struct ctimer buz_timer;
static struct ctimer buz_freq_reset;

void led_toggle();

void led_toggle_off() {
	printf("leds off\n\r");
	leds_off(LEDS_ALL);
	//ctimer_reset(&led_timer);	//turn on after 1 sec
	ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);
}

void led_toggle() {
	//ctimer_reset(&led_timer);
	printf("leds on\n\r");
	if(led_state == LEDS_OFF) {
		leds_off(LEDS_ALL);	
	}
	else if(led_state == LEDS_RED) {
		leds_off(LEDS_ALL);
		leds_toggle(LEDS_RED);
		ctimer_set(&led_off_timer, CLOCK_SECOND, led_toggle_off, NULL); //turn off after 1 sec
	}
	else if(led_state == LEDS_GREEN) {
		leds_off(LEDS_ALL);
		leds_toggle(LEDS_GREEN);
		ctimer_set(&led_off_timer, CLOCK_SECOND, led_toggle_off, NULL); //turn off after 1 sec
	}
	else {
		leds_toggle(LEDS_ALL);
		ctimer_set(&led_off_timer, CLOCK_SECOND, led_toggle_off, NULL); //turn off after 1 sec
	}
	
}



void freq_reset() {
	buz_freq = 1000;
	if (buz_state == 1){buzzer_start(buz_freq);}
	printf("buzzer frequency reset\n\r");
}

void increase() {
	ctimer_set(&buz_freq_reset, 5*CLOCK_SECOND, freq_reset, NULL);
	buz_freq += 50;
	if (buz_state == 1){buzzer_start(buz_freq);}
	printf("buzzer frequency increased to: %i\n\r", buz_freq);
}

void decrease() {
	ctimer_set(&buz_freq_reset, 5*CLOCK_SECOND, freq_reset, NULL);
	buz_freq -= 50;
	if (buz_state == 1){buzzer_start(buz_freq);}
	printf("buzzer frequency decreased to: %i\n\r", buz_freq);
}


/*---------------------------------------------------------------------------*/
PROCESS(input_process, "Serial Input Process");
//PROCESS(led_process, "LED Process");
AUTOSTART_PROCESSES(&input_process); //, &led_process
/*---------------------------------------------------------------------------*/
//input_process
PROCESS_THREAD(input_process, ev, data) {
  	PROCESS_BEGIN();
	cc26xx_uart_set_input(serial_line_input_byte);
	uint8_t mac[8];
	ieee_addr_cpy_to(mac, 8);

	while(1) {
     	PROCESS_YIELD();
		if(ev == serial_line_event_message) {
			printf("received line: %s\n\r", (char *)data);
			if(strcmp(data, "r") == 0) {
				led_state = (led_state == LEDS_RED) ? LEDS_OFF : LEDS_RED;
				ctimer_stop(&led_off_timer);
				ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);
			}
			else if(strcmp(data, "g") == 0) {
				led_state = (led_state == LEDS_GREEN) ? LEDS_OFF : LEDS_GREEN;
				ctimer_stop(&led_off_timer);
				ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);
			}
			else if(strcmp(data, "a") == 0) {
				led_state = (led_state == LEDS_ALL) ? LEDS_OFF : LEDS_ALL;
				ctimer_stop(&led_off_timer);
				ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);	
			}
			else if(strcmp(data, "b") == 0) {
				buz_state = (buz_state == 0) ? 1 : 0;
				(buz_state == 1) ? buzzer_start(buz_freq) : buzzer_stop();				
			}
			else if(strcmp(data, "i") == 0) {
				ctimer_stop(&buz_freq_reset);
				ctimer_set(&buz_timer, CLOCK_SECOND, increase, NULL);		
			}
			else if(strcmp(data, "d") == 0) {
				ctimer_stop(&buz_freq_reset);
				ctimer_set(&buz_timer, CLOCK_SECOND, decrease, NULL);	
			}
			else if(strcmp(data, "n") == 0) {
				//char str[80];
				//sprintf(str, "%02hhx", (char *)mac);
				//puts(str);
				printf("IEEE Address: %02x\n\r", (unsigned int)mac);
			}
		}
	}
  	PROCESS_END();
}

/*---------------------------------------------------------------------------*/







