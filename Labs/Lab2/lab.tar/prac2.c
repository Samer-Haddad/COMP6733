
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contiki.h"
#include "contiki-net.h"
#include "dev/leds.h"
#include "dev/watchdog.h"
#include "board-peripherals.h"

#include "buzzer.h"
#include "dev/cc26xx-uart.h"
#include "ieee-addr.h"
#include "sys/cc.h"
#include "sys/ctimer.h"

#define SERVER_PORT 8080

static struct tcp_socket socket;

#define INPUTBUFSIZE 400
static uint8_t inputbuf[INPUTBUFSIZE];

#define OUTPUTBUFSIZE 400
static uint8_t outputbuf[OUTPUTBUFSIZE];

PROCESS(tcp_server_process, "TCP echo process");
AUTOSTART_PROCESSES(&tcp_server_process);
static uint8_t get_received;
static int bytes_to_send;

int humidity_state = 0;
int humidity_counter = 0;
static struct ctimer humidity_timer;

int pressure_state = 0;
int pressure_counter = 0;
static struct ctimer pressure_timer;

void humidity_sample() {
	if (humidity_counter < 10) {
		tcp_socket_send_str(&socket, "collecting humidity sample\n\r");
		int humidity_temp_val;
		int humidity_val;
		SENSORS_ACTIVATE(hdc_1000_sensor);
		humidity_temp_val = hdc_1000_sensor.value(HDC_1000_SENSOR_TYPE_TEMP);
		humidity_val = hdc_1000_sensor.value(HDC_1000_SENSOR_TYPE_HUMIDITY);
		char humidity[64];
		int n;
		n = sprintf(humidity, "Humidity=%d.%02d %%RH, Temp:%d.%02d C\n\r", humidity_val/100, humidity_val%100, humidity_temp_val/100, humidity_temp_val%100);
		printf(humidity);
		tcp_socket_send_str(&socket, humidity);
		humidity_counter++;
		ctimer_reset(&humidity_timer);
	}
	else {
		humidity_counter = 0;
		//SENSORS_DEACTIVATE(hdc_1000_sensor);
		SENSORS_ACTIVATE(hdc_1000_sensor);
		ctimer_stop(&humidity_timer);	
	}
}

void pressure_sample() {
	if (pressure_counter < 10) {
		tcp_socket_send_str(&socket, "collecting pressure sample\n\r");
		int pressure_temp_val;
		int pressure_val;
		SENSORS_ACTIVATE(bmp_280_sensor);
		pressure_temp_val = bmp_280_sensor.value(BMP_280_SENSOR_TYPE_TEMP);
		pressure_val = hdc_1000_sensor.value(BMP_280_SENSOR_TYPE_PRESS);
		char pressure[64];
		int n;
		n = sprintf(pressure, "Pressure=%d.%02d %%hPa, Temp:%d.%02d C\n\r", pressure_val/100, pressure_val%100, pressure_temp_val/100, pressure_temp_val%100);
		printf(pressure);
		tcp_socket_send_str(&socket, pressure);
		pressure_counter++;
		ctimer_reset(&pressure_timer);
	}
	else {
		pressure_counter = 0;
		//SENSORS_DEACTIVATE(bmp_280_sensor);
		SENSORS_ACTIVATE(bmp_280_sensor);
		ctimer_stop(&pressure_timer);	
	}
}
/////////////////////////

#define LEDS_OFF 0
int led_state = LEDS_OFF;
static struct ctimer led_timer;
static struct ctimer led_off_timer;

int buz_state = 0;
int buz_freq = 1000;
static struct ctimer buz_timer;
static struct ctimer buz_freq_reset;

void led_toggle();

void led_toggle_off() {
	printf("leds off\n\r");
	tcp_socket_send_str(&socket, "leds off\n\r");
	leds_off(LEDS_ALL);
	ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);
}

void led_toggle() {
	printf("leds on\n\r");
	tcp_socket_send_str(&socket, "leds on\n\r");
	if(led_state == LEDS_OFF) {
		leds_off(LEDS_ALL);	
	}
	else if(led_state == LEDS_RED) {
		leds_off(LEDS_ALL);
		leds_toggle(LEDS_RED);
		ctimer_set(&led_off_timer, CLOCK_SECOND, led_toggle_off, NULL); //turn off after 1 sec
	}
	else if(led_state == LEDS_GREEN) {
		leds_off(LEDS_ALL);
		leds_toggle(LEDS_GREEN);
		ctimer_set(&led_off_timer, CLOCK_SECOND, led_toggle_off, NULL); //turn off after 1 sec
	}
	else {
		leds_toggle(LEDS_ALL);
		ctimer_set(&led_off_timer, CLOCK_SECOND, led_toggle_off, NULL); //turn off after 1 sec
	}
	
}

void freq_reset() {
	buz_freq = 1000;
	if (buz_state == 1){buzzer_start(buz_freq);}
	printf("buzzer frequency reset\n\r");
	tcp_socket_send_str(&socket, "buzzer frequency reset\n\r");
}

void increase() {
	ctimer_set(&buz_freq_reset, 5*CLOCK_SECOND, freq_reset, NULL);
	buz_freq += 100;
	if (buz_state == 1){buzzer_start(buz_freq);}
	printf("buzzer frequency increased to: %i\n\r", buz_freq);
	tcp_socket_send_str(&socket, "buzzer frequency increased to: %i\n\r");
}

void decrease() {
	ctimer_set(&buz_freq_reset, 5*CLOCK_SECOND, freq_reset, NULL);
	buz_freq -= 100;
	if (buz_state == 1){buzzer_start(buz_freq);}
	printf("buzzer frequency decreased to: %i\n\r", buz_freq);
	tcp_socket_send_str(&socket, "buzzer frequency decreased to: %i\n\r");
}


/*---------------------------------------------------------------------------*/
//Input data handler
static int input(struct tcp_socket *s, void *ptr, const uint8_t *inputptr, int inputdatalen) {

	//tcp_socket_send_str(&socket, inputptr);	//Reflect byte

	char* c = (char*)inputptr;

	char data[1]; //worked
	int n;
	n = sprintf(data, "%c", c[0]);

	if(strcmp(data, "r") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		led_state = (led_state == LEDS_RED) ? LEDS_OFF : LEDS_RED;
		ctimer_stop(&led_off_timer);
		ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);
	}
	else if(strcmp(data, "g") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		led_state = (led_state == LEDS_GREEN) ? LEDS_OFF : LEDS_GREEN;
		ctimer_stop(&led_off_timer);
		ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);
	}
	else if(strcmp(data, "a") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		led_state = (led_state == LEDS_ALL) ? LEDS_OFF : LEDS_ALL;
		ctimer_stop(&led_off_timer);
		ctimer_set(&led_timer, CLOCK_SECOND, led_toggle, NULL);	
	}
	else if(strcmp(data, "b") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		buz_state = (buz_state == 0) ? 1 : 0;
		(buz_state == 1) ? buzzer_start(buz_freq) : buzzer_stop();				
	}
	else if(strcmp(data, "i") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		ctimer_stop(&buz_freq_reset);
		ctimer_set(&buz_timer, CLOCK_SECOND, increase, NULL);		
	}
	else if(strcmp(data, "d") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		ctimer_stop(&buz_freq_reset);
		ctimer_set(&buz_timer, CLOCK_SECOND, decrease, NULL);	
	}

	///// NEW CODE HERE /////
	else if(strcmp(data, "h") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		if (humidity_state == 0) {
			humidity_state = 1;
			ctimer_set(&humidity_timer, 0.5*CLOCK_SECOND, humidity_sample, NULL);			
		}
		else {
			humidity_state = 0;
			ctimer_stop(&humidity_timer);	
		}
	}

	else if(strcmp(data, "p") == 0) {
		tcp_socket_send_str(&socket, inputptr);	//Reflect byte
		if (pressure_state == 0) {
			pressure_state = 1;
			ctimer_set(&pressure_timer, 0.5*CLOCK_SECOND, pressure_sample, NULL);			
		}
		else {
			pressure_state = 0;
			ctimer_stop(&pressure_timer);	
		}
	}
	/////////////////////////

	//Clear buffer
	memset(inputptr, 0, inputdatalen);
    return 0; // all data consumed 
}

/*---------------------------------------------------------------------------*/
//Event handler
static void event(struct tcp_socket *s, void *ptr, tcp_socket_event_t ev) {
  printf("event %d\n", ev);
}

/*---------------------------------------------------------------------------*/
//TCP Server process
PROCESS_THREAD(tcp_server_process, ev, data) {

  	PROCESS_BEGIN();

	//Register TCP socket
  	tcp_socket_register(&socket, NULL,
               inputbuf, sizeof(inputbuf),
               outputbuf, sizeof(outputbuf),
               input, event);
  	tcp_socket_listen(&socket, SERVER_PORT);

	printf("Listening on %d\n", SERVER_PORT);
	
	while(1) {
	
		//Wait for event to occur
		PROCESS_PAUSE();
	}
	PROCESS_END();
}
/*---------------------------------------------------------------------------*/
