#!/usr/bin/python3
from bluepy.btle import BTLEDisconnectError
from utils import SensorTag
import time
# import threading
import multiprocessing
import numpy as np



def sample_direct(data: np.ndarray):
    data = data.reshape(-1,9)
    try:
        print('Connecting to CC2650...')
        tag = SensorTag("54:6C:0E:53:35:69")
        tag.accelerometer.enable()
        tag.magnetometer.enable()
        tag.gyroscope.enable()
        print('connected')
    except BTLEDisconnectError as e:
        print("error: ", e.message, "\nTry connecting again, or restart the sensortag.")
        exit()

    time.sleep(2.0) #first readings will be rubbish

    while True:
        try:
            w = tag.gyroscope.read()
            a = tag.accelerometer.read()
            m = tag.magnetometer.read()
            line = [*w, *a, *m]
            line = np.array(line, dtype=np.float64)
            # print(line)
            # print(data.shape)
            # print(data)
            data = np.append(data, [line], axis=0)
            # print('added: ', data[-1])
            tag.waitForNotifications(0.001)
        except:
            tag.disconnect()
            del tag
            print('connection closed')
            exit()


def sample():
    try:
        print('Connecting to CC2650...')
        tag = SensorTag("54:6C:0E:53:35:69")
        tag.accelerometer.enable()
        tag.magnetometer.enable()
        tag.gyroscope.enable()
        print('connected')
    except BTLEDisconnectError as e:
        print("error: ", e.message, "\nTry connecting again, or restart the sensortag.")
        exit()

    time.sleep(2.0) #first readings will be rubbish

    f = open('data.txt', 'a')

    while True:
        try:
            w = tag.gyroscope.read()
            a = tag.accelerometer.read()
            m = tag.magnetometer.read()
            line = [*w, *a, *m]
            line = ','.join([str(reading) for reading in line])
            f.write(line + '\n')
            tag.waitForNotifications(0.001)
        except:
            tag.disconnect()
            del tag
            f.close()
            print('connection closed')
            exit()
        

if __name__ == "__main__":
    receive_proc = multiprocessing.Process(target=sample)
    receive_proc.start()
    time.sleep(5)
    i = 0
    while True:
        try:
            with open('data.txt', 'r') as f:
                lines = f.read().splitlines()
                last_line = lines[-1]
                print(last_line)
                #print('trying to print')
            # print(data)
            # print(data[i, 0])
            i += 1
        except FileNotFoundError:
            receive_proc.terminate()
            exit()
        except IndexError:
            continue
        except KeyboardInterrupt:
            receive_proc.terminate()
            exit()
