#-----NOTE: I did not write the Kalman Filter code.
#-----code used from: LibofRelax https://github.com/LibofRelax/IMU-Position-Tracking

import numpy as np
from mathlib import *
import matplotlib.pyplot as plt

import threading
import time
from bluepy.btle import BTLEDisconnectError
from utils import SensorTag

data = np.ndarray((0,9), dtype=np.float64)

def imu_sample():
    global data
    try:
        print('Connecting to CC2650...')
        tag = SensorTag("54:6C:0E:53:35:69")
        tag.accelerometer.enable()
        tag.magnetometer.enable()
        tag.gyroscope.enable()
        print('connected')
    except BTLEDisconnectError as e:
        print("error: ", e.message, "\nTry connecting again, or restart the sensortag.")
        exit()
    time.sleep(2.0) #first readings will be rubbish
    while True:
        try:
            w = tag.gyroscope.read()
            a = tag.accelerometer.read()
            m = tag.magnetometer.read()
            line = [*w, *a, *m]
            line = np.array(line, dtype=np.float64)
            data = np.append(data, [line], axis=0)
            tag.waitForNotifications(0.001)
        except:
            tag.disconnect()
            del tag
            print('connection closed')
            exit()



class IMUTracker:

    def __init__(self, sampling, data_order={'w': 1, 'a': 2, 'm': 3}):

        super().__init__()
        self.sampling = sampling
        self.dt = 1 / sampling
        self.data_order = data_order

        idx = {1: [0, 3], 2: [3, 6], 3: [6, 9]}
        self._widx = idx[data_order['w']]
        self._aidx = idx[data_order['a']]
        self._midx = idx[data_order['m']]

    def initialize(self, data, noise_coefficient={'w': 100, 'a': 100, 'm': 10}):
       
        w = data[:, self._widx[0]:self._widx[1]]
        a = data[:, self._aidx[0]:self._aidx[1]]
        m = data[:, self._midx[0]:self._midx[1]]

        # ---- gravity ----
        gn = -a.mean(axis=0)
        gn = gn[:, np.newaxis]
        g0 = np.linalg.norm(gn)

        # ---- magnetic field ----
        mn = m.mean(axis=0)
        mn = normalized(mn)[:, np.newaxis]

        # ---- compute noise covariance ----
        avar = a.var(axis=0)
        wvar = w.var(axis=0)
        mvar = m.var(axis=0)

        # ---- define sensor noise ----
        gyro_noise = noise_coefficient['w'] * np.linalg.norm(wvar)
        gyro_bias = w.mean(axis=0)
        acc_noise = noise_coefficient['a'] * np.linalg.norm(avar)
        mag_noise = noise_coefficient['m'] * np.linalg.norm(mvar)
        return (gn, g0, mn, gyro_noise, gyro_bias, acc_noise, mag_noise)

    def attitudeTrack(self, data, init_list):
        # ------------------------------- #
        # ---- Initialization ----
        # ------------------------------- #
        gn, g0, mn, gyro_noise, gyro_bias, acc_noise, mag_noise = init_list
        w = data[:, self._widx[0]:self._widx[1]] - gyro_bias
        a = data[:, self._aidx[0]:self._aidx[1]]
        m = data[:, self._midx[0]:self._midx[1]]
        sample_number = np.shape(data)[0]

        # ---- data container ----
        a_nav = []
        orix = []
        oriy = []
        oriz = []

        # ---- states and covariance matrix ----
        P = 1e-10 * I(4)    # state covariance matrix
        q = np.array([[1, 0, 0, 0]]).T    # quaternion state
        init_ori = I(3)   # initial orientation

        # ------------------------------- #
        # ---- Extended Kalman Filter ----
        # ------------------------------- #
        t = 0
        while t < sample_number:
            # ------------------------------- #
            # ---- 0. Data Preparation ----
            # ------------------------------- #
            wt = w[t, np.newaxis].T
            at = a[t, np.newaxis].T
            mt = normalized(m[t, np.newaxis].T)
            # ------------------------------- #
            # ---- 1. Propagation ----
            # ------------------------------- #
            Ft = F(q, wt, self.dt)
            Gt = G(q)
            Q = (gyro_noise * self.dt)**2 * Gt @ Gt.T

            q = normalized(Ft @ q)
            P = Ft @ P @ Ft.T + Q

            # ------------------------------- #
            # ---- 2. Measurement Update ----
            # ------------------------------- #

            # ---- acc and mag prediction ----
            pa = normalized(-rotate(q) @ gn)
            pm = normalized(rotate(q) @ mn)

            # ---- residual ----
            Eps = np.vstack((normalized(at), mt)) - np.vstack((pa, pm))

            # ---- sensor noise ----
            Ra = [(acc_noise / np.linalg.norm(at))**2 + (1 - g0 / np.linalg.norm(at))**2] * 3
            Rm = [mag_noise**2] * 3
            R = np.diag(Ra + Rm)

            # ---- kalman gain ----
            Ht = H(q, gn, mn)
            S = Ht @ P @ Ht.T + R
            K = P @ Ht.T @ np.linalg.inv(S)

            # ---- actual update ----
            q = q + K @ Eps
            P = P - K @ Ht @ P

            # ------------------------------- #
            # ---- 3. Post Correction ----
            # ------------------------------- #

            q = normalized(q)
            P = 0.5 * (P + P.T)

            # ------------------------------- #
            # ---- 4. other things ----
            # ------------------------------- #

            # ---- navigation frame acceleration ----
            conj = -I(4)
            conj[0, 0] = 1
            an = rotate(conj @ q) @ at + gn

            # ---- navigation frame orientation ----
            orin = rotate(conj @ q) @ init_ori

            # ---- saving data ----
            a_nav.append(an.T[0])
            orix.append(orin.T[0, :])
            oriy.append(orin.T[1, :])
            oriz.append(orin.T[2, :])

            t += 1

        a_nav = np.array(a_nav)
        orix = np.array(orix)
        oriy = np.array(oriy)
        oriz = np.array(oriz)
        return (a_nav, orix, oriy, oriz)

    def removeAccErr(self, a_nav, threshold=0.2, filter=False, wn=(0.01, 15)):
        sample_number = np.shape(a_nav)[0]
        t_start = 0
        for t in range(sample_number):
            at = a_nav[t]
            if np.linalg.norm(at) > threshold:
                t_start = t
                break

        t_end = 0
        for t in range(sample_number - 1, -1, -1):
            at = a_nav[t]
            if np.linalg.norm(at - a_nav[-1]) > threshold:
                t_end = t
                break

        an_drift = a_nav[t_end:].mean(axis=0)
        an_drift_rate = an_drift / (t_end - t_start)

        for i in range(t_end - t_start):
            a_nav[t_start + i] -= (i + 1) * an_drift_rate

        for i in range(sample_number - t_end):
            a_nav[t_end + i] -= an_drift

        if filter:
            filtered_a_nav = filtSignal([a_nav], dt=self.dt, wn=wn, btype='bandpass')[0]
            return filtered_a_nav
        else:
            return a_nav

    def zupt(self, a_nav, threshold):
        sample_number = np.shape(a_nav)[0]
        velocities = []
        prevt = -1
        still_phase = False

        v = np.zeros((3, 1))
        t = 0
        while t < sample_number:
            at = a_nav[t, np.newaxis].T

            if np.linalg.norm(at) < threshold:
                if not still_phase:
                    predict_v = v + at * self.dt

                    v_drift_rate = predict_v / (t - prevt)
                    for i in range(t - prevt - 1):
                        velocities[prevt + 1 + i] -= (i + 1) * v_drift_rate.T[0]

                v = np.zeros((3, 1))
                prevt = t
                still_phase = True
            else:
                v = v + at * self.dt
                still_phase = False

            velocities.append(v.T[0])
            t += 1

        velocities = np.array(velocities)
        return velocities

    def positionTrack(self, a_nav, velocities):
        sample_number = np.shape(a_nav)[0]
        positions = []
        p = np.array([[0, 0, 0]]).T

        t = 0
        while t < sample_number:
            at = a_nav[t, np.newaxis].T
            vt = velocities[t, np.newaxis].T

            p = p + vt * self.dt + 0.5 * at * self.dt**2
            positions.append(p.T[0])
            t += 1

        positions = np.array(positions)
        return positions



def plot_trajectory():
    global data
    receive_data_thread = threading.Thread(target=imu_sample)
    receive_data_thread.start()
    time.sleep(30)
    tracker = IMUTracker(sampling=100)
    init_list = tracker.initialize(data[5:30])

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    while True:
        a_nav, orix, oriy, oriz = tracker.attitudeTrack(data[30:], init_list)
        a_nav_filtered = tracker.removeAccErr(a_nav, filter=True)
        v = tracker.zupt(a_nav_filtered, threshold=0.2)
        p = tracker.positionTrack(a_nav_filtered, v)
        p = p[-1]
        ax.clear()
        ax.set_xlabel('X axis')
        ax.set_ylabel('Y axis')
        ax.set_zlabel('Z axis')
        ax.set_xlim([-10, 10])
        ax.set_ylim([-10, 10])
        ax.set_zlim([-10, 10])
        ax.plot(p[0], p[1], p[2], 'ro', label='position')
        plt.draw()
        plt.pause(0.001)


if __name__ == '__main__':
    plot_trajectory()
